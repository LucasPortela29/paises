package com.example.atividade_paises

import android.app.Application

class App: Application() {

    companion object {
        var paises: List<Pais> = listOf(
            Pais(R.drawable.brazil,"Brazil", false),
            Pais(R.drawable.argentina,"Argentina",false),
            Pais(R.drawable.polonia,"Polonia",false),
            Pais(R.drawable.ucrania,"Ucrânia",false),
            Pais(R.drawable.usinedstates,"Estados Unidos da América",false),
        )

        val paisesFavoritos get() = paises.filter { it.curt }
    }
}