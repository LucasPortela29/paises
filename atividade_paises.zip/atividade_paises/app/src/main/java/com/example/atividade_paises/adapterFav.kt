package com.example.atividade_paises

import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.core.content.ContextCompat.startActivity
import androidx.recyclerview.widget.RecyclerView

class adapterFav(val mudar : (banda: Int, nome:String) -> Unit) : RecyclerView.Adapter<PaisHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PaisHolder {
        var view: View =LayoutInflater.from(parent.context).inflate(R.layout.lista,parent,false)
        return PaisHolder(view)
    }

    override fun getItemCount(): Int {
        return App.paisesFavoritos.size
    }

    override fun onBindViewHolder(holder: PaisHolder, position: Int) {
        holder.bandaPais.setImageResource(App.paisesFavoritos[position].banda)
        holder.nomePais.text = App.paisesFavoritos[position].nome
        holder.coracao.setImageResource(R.drawable.coracao_sem_voce)

        if (App.paisesFavoritos[position].curt){
            holder.coracao.setImageResource(R.drawable.coracao_com_voce)
        } else {
            holder.coracao.setImageResource(R.drawable.coracao_sem_voce)
        }

        holder.coracao.setOnClickListener{
            if (!App.paisesFavoritos[position].curt){
                holder.coracao.setImageResource(R.drawable.coracao_com_voce)
                App.paisesFavoritos[position].curt = true
            } else {
                holder.coracao.setImageResource(R.drawable.coracao_sem_voce)
                App.paisesFavoritos[position].curt = false
            }
        }

        holder.itemView.setOnClickListener{
            mudar.invoke(App.paisesFavoritos[position].banda,App.paisesFavoritos[position].nome)
        }
    }

}